package DataBase;


import java.util.Date;

/**
 * Classe con tutti i Constructors di Allarme.
 */

public class Allarme {

	int ID_Allarme;
	Date Data_Inizio;
	Date Data_Fine;
	
	public Allarme(int iD_Allarme, Date data_Inizio, Date data_Fine) {
		super();
		this.ID_Allarme = iD_Allarme;
		this.Data_Inizio = data_Inizio;
		this.Data_Fine = data_Fine;
	
	}
	public int getID_Allarme() {
		return ID_Allarme;
	}
	public void setID_Allarme(int iD_Allarme) {
		ID_Allarme = iD_Allarme;
	}
	public Date getData_Inizio() {
		return Data_Inizio;
	}
	
	public void setData_Inizio(Date data_Inizio) {
		Data_Inizio = data_Inizio;
	}
	public Date getData_Fine() {
		return Data_Fine;
	}
	public void setData_Fine(Date data_Fine) {
		Data_Fine = data_Fine;
	}
	
	@Override
	public String toString() {
		return "Allarme [ID_Allarme=" + ID_Allarme + ", Data_Inizio=" + Data_Inizio + ", Data_Fine=" + Data_Fine + "]";
	}
	
	
}
