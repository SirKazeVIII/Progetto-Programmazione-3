package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.commons.lang.StringEscapeUtils;


/**
 * Classe per la gestione (Lettura, Srittura, Modifica, Eliminazione) di  dati dal database.
 * @author Vincenzo Guida 
 *
 */

public class Gestione_Database {

	/**
	 * Metodo che restituisce tutti i valori della tabella Sensori Monitoraggio 
	 * @return
	 * @throws SQLException
	 */
	
public static ArrayList<Sensori_Monitoraggio> elenco_SM () throws SQLException {
		
		ArrayList<Sensori_Monitoraggio> elenco_sm = new ArrayList<Sensori_Monitoraggio>();
		Connection cn;
		Statement st;
		ResultSet rs;
		String sql;
		// ________________________________connessione
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			System.err.println(e.getMessage());
		} // fine try-catch

		// Creo la connessione al database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/programmazione_3?user=root&password=");
		// peer � il nome del database

		sql = "SELECT Nome_SM, Tipo_Consumo_SM, Consumo_SM, Sensore_Attivato, AddOn FROM sensori_monitoraggio;";
		// ________________________________query
		try {
			st = cn.createStatement(); // creo sempre uno statement sulla
										// connessione
			rs = st.executeQuery(sql); // faccio la query su uno statement
			while (rs.next() == true) {
				Sensori_Monitoraggio sm = new Sensori_Monitoraggio (rs.getString("Nome_Sm"), rs.getString("Tipo_Consumo_SM"), rs.getInt("Consumo_SM"), rs.getString("Sensore_Attivato"), rs.getString("AddOn"));
			elenco_sm.add(sm);
			}
		} catch (SQLException e) {
			System.out.println("errore:" + e.getMessage());
		} // fine try-catch
		return elenco_sm;	
	}
	
	/**
	 * Metodo che restituisce tutti i valori della tabella Sensori Attivi
	 * @return
	 * @throws SQLException
	 */
public static ArrayList<Sensori_Attivabili> elenco_SA () throws SQLException {
		
		ArrayList<Sensori_Attivabili> elenco_sa = new ArrayList<Sensori_Attivabili>();
		Connection cn;
		Statement st;
		ResultSet rs;
		String sql;
		// ________________________________connessione
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			System.err.println(e.getMessage());
		} // fine try-catch

		// Creo la connessione al database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/programmazione_3?user=root&password=");
		// peer � il nome del database

		sql = "SELECT Nome_SA, Tipo_Consumo_SA, Consumo_SA, Tempo_attivazione, AddOn FROM sensori_attivabili;";
		// ________________________________query
		try {
			st = cn.createStatement(); // creo sempre uno statement sulla
										// connessione
			rs = st.executeQuery(sql); // faccio la query su uno statement
			while (rs.next() == true) {
				Sensori_Attivabili sa = new Sensori_Attivabili (rs.getString("Nome_SA"), rs.getString("Tipo_Consumo_SA"), rs.getInt("Consumo_SA"), rs.getInt("Tempo_Attivazione"), rs.getString("AddOn"));
			elenco_sa.add(sa);
			}
		} catch (SQLException e) {
			System.out.println("errore:" + e.getMessage());
		} // fine try-catch
		return elenco_sa;
	}

	
	/**
	 * Metodo che restituisce tutti i valori della tabella Allarme
	 * @return
	 * @throws SQLException
	 */
public static ArrayList<Allarme> elenco_A () throws SQLException {
		
		ArrayList<Allarme> elenco_a = new ArrayList<Allarme>();
		Connection cn;
		Statement st;
		ResultSet rs;
		String sql;
		// ________________________________connessione
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			System.err.println(e.getMessage());
		} // fine try-catch

		// Creo la connessione al database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/programmazione_3?user=root&password=");
		// peer � il nome del database

		sql = "SELECT ID_Allarme, Data_Inizio, Data_Fine FROM allarme;";
		// ________________________________query
		try {
			st = cn.createStatement(); // creo sempre uno statement sulla
										// connessione
			rs = st.executeQuery(sql); // faccio la query su uno statement
			while (rs.next() == true) {
				Allarme a = new Allarme (rs.getInt("ID_Allarme"), rs.getTimestamp("Data_Inizio"), rs.getTimestamp("Data_Fine"));
			elenco_a.add(a);
			}
		} catch (SQLException e) {
			System.out.println("errore:" + e.getMessage());
		} // fine try-catch
		return elenco_a;
	}

/**
 * Metodo che eliminazione Tupla nella tabella Sensore_Monitoraggio
 * @param ESM
 */
public static void eliminaSensore_Monitoraggio(Sensori_Monitoraggio ESM) {
	Connection cn;
	Statement st;
	String sql;
	// ________________________________connessione
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		System.out.println("ClassNotFoundException: ");
		System.err.println(e.getMessage());
	} // fine try-catch
	try {
		// Creo la connessione al database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Programmazione_3?user=root&password=");

		// Recupero La chiave della tabella 
		String Nome_SM = StringEscapeUtils.escapeSql (ESM.getNome_SM());
		sql = "delete from sensori_monitoraggio where Nome_SM='"+Nome_SM+"'";
		System.out.println(sql); // stampa la query
		// ________________________________query

		st = cn.createStatement(); // creo sempre uno statement sulla
									// connessione
		st.execute(sql); // faccio la query su uno statement
		cn.close(); // chiusura connessione
	} catch (SQLException e) {
		System.out.println("errore:" + e.getMessage());
	} // fine try-catch
	
}

/**
 * Metodo che eliminazione Tupla nella tabella Sensore_Attivabili
 * @param ESA
 */

public static void eliminaSensore_Attivabili(Sensori_Attivabili ESA) {
	Connection cn;
	Statement st;
	String sql;
	// ________________________________connessione
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		System.out.println("ClassNotFoundException: ");
		System.err.println(e.getMessage());
	} // fine try-catch
	try {
		// Creo la connessione al database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Programmazione_3?user=root&password=");

		// Recupero La chiave della tabella 
		String Nome_SA = StringEscapeUtils.escapeSql (ESA.getNome_SA());
		sql = "delete from sensori_attivabili where Nome_SA='"+Nome_SA+"'";
		System.out.println(sql); // stampa la query
		// ________________________________query

		st = cn.createStatement(); // creo sempre uno statement sulla
									// connessione
		st.execute(sql); // faccio la query su uno statement
		cn.close(); // chiusura connessione
	} catch (SQLException e) {
		System.out.println("errore:" + e.getMessage());
	} // fine try-catch
}

/**
 * Metodo che eliminazione Tupla nella tabella Allarmi
 * @param EA
*/

public static void eliminaAllarme (Allarme EA) {
	Connection cn;
	Statement st;
	String sql;
	// ________________________________connessione
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		System.out.println("ClassNotFoundException: ");
		System.err.println(e.getMessage());
	} // fine try-catch
	try {
		// Creo la connessione al database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Programmazione_3?user=root&password=");

		// Recupero La chiave della tabella 
		int ID_Allarme = EA.getID_Allarme();
		sql = "delete from allarme where ID_Allarme=" + ID_Allarme;
		System.out.println(sql); // stampa la query
		// ________________________________query

		st = cn.createStatement(); // creo sempre uno statement sulla
									// connessione
		st.execute(sql); // faccio la query su uno statement
		cn.close(); // chiusura connessione
	} catch (SQLException e) {
		System.out.println("errore:" + e.getMessage());
	} // fine try-catch
}


/**
 * Metodo per eliminare tutte le Tuple all'interno della tabella Allarmi, 
 * cosi da avere un reset di tutte le attivazioni precedenti.
 * @param RA
 * @throws SQLException
 */
public static void ResetAllarme(Allarme RA) {
	Connection cn;
	Statement st;
	String sql;
	// ________________________________connessione
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		System.out.println("ClassNotFoundException: ");
		System.err.println(e.getMessage());
	} // fine try-catch
	try {
		// Creo la connessione al database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Programmazione_3?user=root&password=");

		// Recupero La chiave della tabella 
		sql = "truncate table allarme";
		System.out.println(sql); // stampa la query
		// ________________________________query

		st = cn.createStatement(); // creo sempre uno statement sulla
									// connessione
		st.execute(sql); // faccio la query su uno statement
		cn.close(); // chiusura connessione
	} catch (SQLException e) {
		System.out.println("errore:" + e.getMessage());
	} // fine try-catch
}

/**
 * Metodo per aggiungere una nuova tupla alla tabella Sensori_Monitoraggio
 * @param NSM
 */
public static void NuovoSensore_Monitoraggio(Sensori_Monitoraggio NSM) {
	Connection cn;
	Statement st;
	String sql;
	// ________________________________connessione
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		System.out.println("ClassNotFoundException: ");
		System.err.println(e.getMessage());
	} // fine try-catch

	try {
		// Creo la connessione al database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Programmazione_3?user=root&password=");

		String Nome_SM = StringEscapeUtils.escapeSql(NSM.getNome_SM());
		String Tipo_Comsumo_SM = StringEscapeUtils.escapeSql(NSM.getTipo_Consumo_SM());
		int Consumo_SM = NSM.getConsumo_SM();
		String Sensore_Attivato = StringEscapeUtils.escapeSql(NSM.getSensore_Attivato());
		String AddOn = StringEscapeUtils.escapeSql(NSM.getAddOn());

		sql = "insert into sensori_monitoraggio (Nome_SM, Tipo_Consumo_SM, Consumo_SM, Sensore_Attivato, AddOn) values ('" + Nome_SM + "','" + Tipo_Comsumo_SM + "','" + Consumo_SM + "','" +Sensore_Attivato+ "','" +AddOn+ "')";
		System.out.println(sql);
		// ________________________________query

		st = cn.createStatement(); // creo sempre uno statement sulla
									// connessione
		st.execute(sql); // faccio la query su uno statement
		cn.close(); // chiusura connessione
	} catch (SQLException e) {
		System.out.println("errore:" + e.getMessage());
	} // fine try-catch

}

/**
 * Metodo per aggiungere una nuova tupla alla tabella Sensori_Attivabili
 * @param NSA
 */
public static void NuovoSensore_Attivabili(Sensori_Attivabili NSA) {
	Connection cn;
	Statement st;
	String sql;
	// ________________________________connessione
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		System.out.println("ClassNotFoundException: ");
		System.err.println(e.getMessage());
	} // fine try-catch

	try {
		// Creo la connessione al database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Programmazione_3?user=root&password=");

		String Nome_SA = StringEscapeUtils.escapeSql(NSA.getNome_SA());
		String Tipo_Comsumo_SA = StringEscapeUtils.escapeSql(NSA.getTipo_Consumo_SA());
		int Consumo_SA = NSA.getConsumo_SA();
		int Tempo_Attivazione = NSA.getTempo_Attivazione();
		String AddOn = StringEscapeUtils.escapeSql(NSA.getAddOn());

		sql = "insert into sensori_attivabili (Nome_SA, Tipo_Consumo_SA, Consumo_SA, Tempo_Attivazione, AddOn) values ('" + Nome_SA + "','" + Tipo_Comsumo_SA + "','" + Consumo_SA + "','" + Tempo_Attivazione + "','" + AddOn + "')";
		System.out.println(sql);
		// ________________________________query

		st = cn.createStatement(); // creo sempre uno statement sulla
									// connessione
		st.execute(sql); // faccio la query su uno statement
		cn.close(); // chiusura connessione
	} catch (SQLException e) {
		System.out.println("errore:" + e.getMessage());
	} // fine try-catch

}

/**
 * Metodo per aggiungere una nuova tupla alla tabella Allarme
 * @param NA
 */
public static void NuovoAllarme(Allarme NA) {
	Connection cn;
	Statement st;
	String sql;
	// ________________________________connessione
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		System.out.println("ClassNotFoundException: ");
		System.err.println(e.getMessage());
	} // fine try-catch

	try {
		// Creo la connessione al database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Programmazione_3?user=root&password=");

		int ID_Allarme = NA.getID_Allarme();
		
		Calendar Data_Inizio = Calendar.getInstance();
		Data_Inizio.setTime (NA.getData_Inizio());
		String sqlData = Data_Inizio.get(Calendar.YEAR) + "-" + Data_Inizio.get(Calendar.MONTH) + "-" + Data_Inizio.get(Calendar.DAY_OF_MONTH) + ":" + Data_Inizio.get(Calendar.HOUR_OF_DAY) + ":" + Data_Inizio.get(Calendar.MINUTE) + ":" + Data_Inizio.get(Calendar.SECOND);
		
		Calendar Data_Fine = Calendar.getInstance();
		Data_Fine.setTime (NA.getData_Fine());
		String sql_Data = Data_Fine.get(Calendar.YEAR) + "-" + Data_Fine.get(Calendar.MONTH) + "-" + Data_Fine.get(Calendar.DAY_OF_MONTH) + "-" + Data_Fine.get(Calendar.HOUR_OF_DAY) + ":" + Data_Fine.get(Calendar.MINUTE) + ":" + Data_Fine.get(Calendar.SECOND);

		sql = "insert into allarme (ID_Allarme, Data_Inizio, Data_Fine) values ('" + ID_Allarme + "','" + sqlData + "','" + sql_Data + "')";
		System.out.println(sql);
		// ________________________________query

		st = cn.createStatement(); // creo sempre uno statement sulla
									// connessione
		st.execute(sql); // faccio la query su uno statement
		cn.close(); // chiusura connessione
	} catch (SQLException e) {
		System.out.println("errore:" + e.getMessage());
	} // fine try-catch

}

/**
 * Metodo per aggiungere un AddOn alla tabella Sensori Monitoraggio
 * @param MSM
 */
public static void modificaSensoreMonitoraggio (Sensori_Monitoraggio MSM) {
	Connection cn;
	Statement st;
	String sql;
	// ________________________________connessione
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		System.out.println("ClassNotFoundException: ");
		System.err.println(e.getMessage());
	} // fine try-catch
	try {
		// Creo la connessione al database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Programmazione_3?user=root&password=");

		// Inserisco nelle variabili i valori da modificare
		String Nome_SM = StringEscapeUtils.escapeSql(MSM.getNome_SM());
		int Consumo_SM = MSM.getConsumo_SM();
		String AddOn = StringEscapeUtils.escapeSql(MSM.getAddOn());

		sql = "update sensori_monitoraggio set  Consumo_SM = '" + Consumo_SM + "', AddOn='" + AddOn + "' where Nome_SM = '"+Nome_SM+"'";
		
		System.out.println(sql); // stampa la query
		// ________________________________query

		st = cn.createStatement(); // creo sempre uno statement sulla
									// connessione
		st.execute(sql); // faccio la query su uno statement
		cn.close(); // chiusura connessione
	} catch (SQLException e) {
		System.out.println("errore:" + e.getMessage());
	} // fine try-catch

}

/**
 * Metodo per aggiungere un AddOn alla tabella Sensori Monitoraggio
 * @param MSA
 */
public static void modificaSensoreAttivabile (Sensori_Attivabili MSA) {
	Connection cn;
	Statement st;
	String sql;
	// ________________________________connessione
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		System.out.println("ClassNotFoundException: ");
		System.err.println(e.getMessage());
	} // fine try-catch
	try {
		// Creo la connessione al database
		cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Programmazione_3?user=root&password=");

		// Inserisco nelle variabili i valori da modificare
		String Nome_SA = StringEscapeUtils.escapeSql(MSA.getNome_SA());
		int Consumo_SA = MSA.getConsumo_SA();
		String AddOn = StringEscapeUtils.escapeSql(MSA.getAddOn());

		sql = "update sensori_attivabili set Consumo_SA = '" + Consumo_SA + "',AddOn='" + AddOn + "' where Nome_SA = '"+Nome_SA+"'";
		
		System.out.println(sql); // stampa la query
		// ________________________________query

		st = cn.createStatement(); // creo sempre uno statement sulla
									// connessione
		st.execute(sql); // faccio la query su uno statement
		cn.close(); // chiusura connessione
	} catch (SQLException e) {
		System.out.println("errore:" + e.getMessage());
	} // fine try-catch

}

	//Verifica Se Gestione_Database funziona correttamente 
	public static void main(String[] args) throws SQLException, ParseException {
		java.text.DateFormat df = new SimpleDateFormat ("yyyy-MM-dd:kk:mm:ss");
		java.text.DateFormat dff = new SimpleDateFormat ("yyyy-MM-dd:kk:mm:ss");
		System.out.println (Gestione_Database.elenco_SM());
		System.out.println (Gestione_Database.elenco_SA());
		System.out.println (Gestione_Database.elenco_A());
		Gestione_Database.eliminaSensore_Monitoraggio (new Sensori_Monitoraggio ("Telecamera", null, 0, null, null));
		Gestione_Database.eliminaSensore_Attivabili(new Sensori_Attivabili ("Allarme", null, 0, 0, null));
		Gestione_Database.eliminaAllarme(new Allarme (1, null, null));
		Gestione_Database.ResetAllarme(null);
		Gestione_Database.NuovoSensore_Monitoraggio (new Sensori_Monitoraggio ("Telecamera", "KWH", 5, "Allarme", "Microfono"));
		Gestione_Database.NuovoSensore_Monitoraggio (new Sensori_Monitoraggio ("Telecamera2", "KWH", 5, "Allarme", null));
		Gestione_Database.NuovoSensore_Attivabili(new Sensori_Attivabili ("Sistema Anti Incendio" , "KWH", 10, 5, "Cassa"));
		Gestione_Database.NuovoAllarme(new Allarme (0, df.parse("2019-09-10:11:50:00"), (dff.parse("2020-09-10:10:51:00"))));
		Gestione_Database.NuovoAllarme(new Allarme (0, df.parse("2019-09-10:11:50:00"), (dff.parse("2020-09-10:10:51:00"))));
		Gestione_Database.modificaSensoreMonitoraggio(new Sensori_Monitoraggio ("Telecamera2",null,0,null,"vediamo se va"));
		Gestione_Database.modificaSensoreAttivabile(new Sensori_Attivabili("Allarme Anti incendio", null, 0, 0, "funziona?"));
	}

}
