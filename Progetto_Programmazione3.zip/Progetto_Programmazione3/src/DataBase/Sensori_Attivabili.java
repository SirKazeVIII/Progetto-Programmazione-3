package DataBase;

/**
 * Classe con tutti i Constructors di Sensori Attivabili.
 */

public class Sensori_Attivabili {
	
	String Nome_SA;
	String Tipo_Consumo_SA;
	int Consumo_SA;
	int Tempo_Attivazione;
	String AddOn;
	
	public Sensori_Attivabili(String nome_SA, String tipo_Consumo_SA, int consumo_SA, int tempo_Attivazione, String addOn) {
		super();
		this.Nome_SA = nome_SA;
		this.Tipo_Consumo_SA = tipo_Consumo_SA;
		this.Consumo_SA = consumo_SA;
		this.Tempo_Attivazione = tempo_Attivazione;
		this.AddOn = addOn;
	}
	
	public String getNome_SA() {
		return Nome_SA;
	}
	public void setNome_SA(String nome_SA) {
		Nome_SA = nome_SA;
	}
	public String getTipo_Consumo_SA() {
		return Tipo_Consumo_SA;
	}
	public void setTipo_Consumo_SA(String tipo_Consumo_SA) {
		Tipo_Consumo_SA = tipo_Consumo_SA;
	}
	public int getConsumo_SA() {
		return Consumo_SA;
	}
	public void setConsumo_SA(int consumo_SA) {
		Consumo_SA = consumo_SA;
	}
	public int getTempo_Attivazione() {
		return Tempo_Attivazione;
	}
	public void setTempo_Attivazione(int tempo_Attivazione) {
		Tempo_Attivazione = tempo_Attivazione;
	}
	public String getAddOn() {
		return AddOn;
	}
	public void setAddOn(String addOn) {
		AddOn = addOn;
	}

	@Override
	public String toString() {
		return "Sensori_Attivabili [Nome_SA=" + Nome_SA + ", Tipo_Consumo_SA=" + Tipo_Consumo_SA + ", Consumo_SA="
				+ Consumo_SA + ", Tempo_Attivazione=" + Tempo_Attivazione + ", AddOn=" + AddOn + "]";
	}
	
	

}
