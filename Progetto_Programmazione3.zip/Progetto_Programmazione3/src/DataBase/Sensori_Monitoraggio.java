package DataBase;

/**
 * Classe con tutti i Constructors di Sensori Monitoraggio.
 */

public class Sensori_Monitoraggio {
	
	String Nome_SM;
	String Tipo_Consumo_SM;
	int Consumo_SM;
	String Sensore_Attivato;
	String AddOn;
		
	
	public String getNome_SM() {
		return Nome_SM;
	}
	public void setNome_SM(String nome_SM) {
		Nome_SM = nome_SM;
	}
	public String getTipo_Consumo_SM() {
		return Tipo_Consumo_SM;
	}
	public void setTipo_Consumo_SM(String tipo_Consumo_SM) {
		Tipo_Consumo_SM = tipo_Consumo_SM;
	}
	public int getConsumo_SM() {
		return Consumo_SM;
	}
	public void setConsumo_SM(int consumo_SM) {
		Consumo_SM = consumo_SM;
	}
	public String getSensore_Attivato() {
		return Sensore_Attivato;
	}
	public void setSensore_Attivato(String sensore_Attivato) {
		Sensore_Attivato = sensore_Attivato;
	}
	
	public String getAddOn() {
		return AddOn;
	}
	public void setAdd_On(String addOn) {
		AddOn = addOn;
	}
	
	public Sensori_Monitoraggio(String nome_SM, String tipo_Consumo_SM, int consumo_SM, String sensore_Attivato, String addOn) {
		super();
		Nome_SM = nome_SM;
		Tipo_Consumo_SM = tipo_Consumo_SM;
		Consumo_SM = consumo_SM;
		Sensore_Attivato = sensore_Attivato;
		AddOn = addOn;
	}
	
	@Override
	public String toString() {
		return "Sensori_Monitoraggio [Nome_SM=" + Nome_SM + ", Tipo_Consumo_SM=" + Tipo_Consumo_SM + ", Consumo_SM="
				+ Consumo_SM + ", Sensore_Attivato=" + Sensore_Attivato + ", AddOn=" + AddOn + "]";
	}
}
