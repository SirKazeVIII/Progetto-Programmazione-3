package DataBase;

import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 * Prova del DB per verificare tutti i metodi creati, all'interno di una interfaccia grafica.
 */

public class prova {

	private JFrame frame;
	private ArrayList<Sensori_Monitoraggio> elenco_SM = new ArrayList<Sensori_Monitoraggio>();
	private List list;
	private JTextField textNome;
	private JTextField textTipo_Consumo;
	private JTextField textConsumo;
	private JTextField textSensore_Attivato;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					prova window = new prova();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public prova() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		list = new List();
		list.setBounds(0, 64, 237, 197);
		frame.getContentPane().add(list);
		
		JButton Back = new JButton("<-");
		Back.setBounds(10, 11, 45, 23);
		frame.getContentPane().add(Back);
		
		//Bottone per eliminare i Sensori di Monitoraggio 
		JButton elimina = new JButton("Elimina\r\n");
		elimina.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int elementoSelezionato = list.getSelectedIndex();
				Gestione_Database.eliminaSensore_Monitoraggio(elenco_SM.get(elementoSelezionato));
				// Ricarico la lista per vedere l'effettiva eliminazione
				carica_SensoriMonitoraggio();
			}
		});
		elimina.setBounds(345, 64, 89, 23);
		frame.getContentPane().add(elimina);
		
		
		//bottone per visualizzare i contenuti della tabella SensoriMonitoraggio
		JButton visualizza = new JButton("Visualizza");
		visualizza.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					carica_SensoriMonitoraggio();
				}
		});
		
		
		visualizza.setBounds(243, 64, 89, 23);
		frame.getContentPane().add(visualizza);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setBounds(243, 121, 46, 14);
		frame.getContentPane().add(lblNewLabel);
		
		textNome = new JTextField();
		textNome.setBounds(243, 136, 86, 20);
		frame.getContentPane().add(textNome);
		textNome.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Tipo consumo");
		lblNewLabel_1.setBounds(349, 121, 85, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		textTipo_Consumo = new JTextField();
		textTipo_Consumo.setBounds(348, 136, 86, 20);
		frame.getContentPane().add(textTipo_Consumo);
		textTipo_Consumo.setColumns(10);
		
		textConsumo = new JTextField();
		textConsumo.setBounds(243, 183, 86, 20);
		frame.getContentPane().add(textConsumo);
		textConsumo.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Consumo");
		lblNewLabel_2.setBounds(243, 167, 46, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		textSensore_Attivato = new JTextField();
		textSensore_Attivato.setBounds(345, 183, 86, 20);
		frame.getContentPane().add(textSensore_Attivato);
		textSensore_Attivato.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Sensore Attivato");
		lblNewLabel_3.setBounds(345, 167, 89, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		//pulsante per inserire i dati nel database
		JButton salva = new JButton("Salva");
		salva.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nome = textNome.getText();
				String tipo_consumo = textTipo_Consumo.getText();
				String consumo = textConsumo.getText();
				int consumo1 = Integer.parseInt(consumo);
				String sensore_attivato = textSensore_Attivato.getText();
				if (nome == null) {
					carica_SensoriMonitoraggio();
				}
				else {
				Sensori_Monitoraggio salvaSM = new Sensori_Monitoraggio (nome, tipo_consumo, consumo1, sensore_attivato, null);
				Gestione_Database.NuovoSensore_Monitoraggio(salvaSM);
				
				//ricarico la lista
				carica_SensoriMonitoraggio();
				}
			}
		});
		salva.setBounds(345, 224, 89, 23);
		frame.getContentPane().add(salva);
		
		JLabel lblNewLabel_4 = new JLabel("Nome");
		lblNewLabel_4.setBounds(9, 44, 46, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Tip.Cons");
		lblNewLabel_5.setBounds(65, 44, 46, 14);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Consumo");
		lblNewLabel_6.setBounds(121, 44, 46, 14);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("S. Attivato");
		lblNewLabel_7.setBounds(177, 44, 60, 14);
		frame.getContentPane().add(lblNewLabel_7);
	}
	
	//Funzione per inssrire nell'array list tutti i valori della tabella sensori monitoraggio
	public void carica_SensoriMonitoraggio() {
		try {
			elenco_SM = Gestione_Database.elenco_SM();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
			list.removeAll();
			for (int i = 0; i<elenco_SM.size(); i++) {
				list.add (elenco_SM.get(i).getNome_SM() + " " + elenco_SM.get(i).getTipo_Consumo_SM() + " " + elenco_SM.get(i).getConsumo_SM() + " " + elenco_SM.get(i).getSensore_Attivato());
			}	
	}
}