package decorator_Pattern;

/**
 * Classe con tutti i Constructors per il Decorator Pattern di AddOn.
 */

public class Add_On extends ExtraAdditionDecorator {
	
	public Add_On (Client client) {
		this.client = client;
	}

	@Override
	public String getTipoSensore() {
		return client.getTipoSensore();
	}
	
	@Override
	public String getNomeSensore() {
		return client.getNomeSensore() + " Add-On Agginto:";
	}
	
	@Override
	public int getConsumo() {
		return client.getConsumo();
	}
}

