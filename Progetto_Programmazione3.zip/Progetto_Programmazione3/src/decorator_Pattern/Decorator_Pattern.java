package decorator_Pattern;

/**
 * Classe per provare il funzionamento del decorator pattern.
 */
public class Decorator_Pattern {

	public static void main(String[] args) {
		Client smadd = new Add_On (new SensoreMonitoraggio());  
		System.out.println("Tipo Sensore: "+ smadd.getTipoSensore() + " Nome Sensore:" + smadd.getNomeSensore() + "Consumo Totale" + smadd.getConsumo());
		Client saadd = new Add_On (new SensoreAttivo());  
		System.out.println("Tipo Sensore: "+ saadd.getTipoSensore() + " Nome Sensore:" + saadd.getNomeSensore() + "Consumo Totale" + saadd.getConsumo());
	}
	
}