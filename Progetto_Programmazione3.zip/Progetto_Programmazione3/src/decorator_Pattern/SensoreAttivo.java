package decorator_Pattern;

/**
 * Classe con tutti i Constructors per il Decorator Pattern di Sensore Attivo.
 */

public class SensoreAttivo extends Client{
	public SensoreAttivo () {
		TipoSensore = "Sensore Attivo";
	}

	@Override
	public String getNomeSensore() {
		return null;
	}
	
	@Override
	public int getConsumo() {
		return 10;
	}
}
