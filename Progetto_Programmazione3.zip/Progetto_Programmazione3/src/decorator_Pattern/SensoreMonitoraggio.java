package decorator_Pattern;

/**
 * Classe con tutti i Constructors per il Decorator Pattern di Sensore Monitoraggio.
 */

public class SensoreMonitoraggio extends Client{
	public SensoreMonitoraggio () {
		TipoSensore = "Sensore Monitoraggio";
	}

	@Override
	public String getNomeSensore() {
		return null;
	}
	
	@Override
	public int getConsumo() {
		return 5;
	}
}
