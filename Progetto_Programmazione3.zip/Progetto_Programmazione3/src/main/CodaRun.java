package main;

/**
 * Classe Runnable che gestisce i vari errori, e li aggiunge al DB una volta risolti.
 */

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Queue;

import DataBase.Allarme;
import DataBase.Gestione_Database;
import singleton_Pattern.Singleton;


public class CodaRun implements Runnable {
	
				
			CreaRun CR;

		public CodaRun (CreaRun CR) {
					this.CR = CR;
				}

	@Override
	public void run() {
			int attiva = 1;
			Queue<Integer> coda = CR.getCoda();
			int temp;
			while (attiva == 1) {
				Singleton s2 = Singleton.factory();
				attiva = s2.getMyInt2();
				
				//If che controlla se la coda � vuota. Se la coda � vuota aspetta un minuto.
				if(coda.isEmpty()) {
					try {
						Thread.sleep(60000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				//Else che gestisce il poll dalla queue e che moltiplica il tempo di attivazione * un minuto
				else {
					temp = coda.poll();
					System.out.println(coda + "\n-----------------------------");
					temp = temp*60000;
					System.out.println(temp + "\n-----------------------------");
					try {
						Thread.sleep(temp);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					//Salvataggio nel DB dell'allarme
					SimpleDateFormat dateFormat = new SimpleDateFormat ("yyyy-MM-dd:kk:mm:ss");
					Date d = new Date();
					String frmtdDate = dateFormat.format(d);
					System.out.println(frmtdDate + "\n-----------------------------");
					Calendar cal = Calendar.getInstance();
					cal.setTime(d);
					int minuti = temp / 60000;
					cal.add(Calendar.MINUTE, -minuti);
					System.out.println("cal =" +cal);
					Date d1 = cal.getTime();
					System.out.println("d1 =" +d1 + "\n-----------------------------");

					Gestione_Database.NuovoAllarme(new Allarme (0, d1, d));
					
				}
			System.out.println("Coda ora contiene: " + coda + "\n-----------------------------");
			}
		}

}