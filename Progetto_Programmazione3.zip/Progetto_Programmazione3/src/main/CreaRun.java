package main;

/**
 * Classe Runnable che crea i vari errori, e che aggiunge alla Queue coda il tempo di attivazione dei vari sensori attivabili.
 */


import java.sql.SQLException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;

import DataBase.Gestione_Database;
import DataBase.Sensori_Attivabili;
import DataBase.Sensori_Monitoraggio;
import singleton_Pattern.Singleton;
import state_Pattern.*;

public class CreaRun implements Runnable {

	Allarme allarme = new Allarme();
	
	private Queue<Integer> coda = new ArrayDeque<Integer>();
	
	public void crea (Queue<Integer> coda) {
		this.coda = coda;
	}
	public Queue<Integer> getCoda () {
		return this.coda;
	}

	@Override
	public void run() {
	
		int attiva = 1;
		coda = getCoda();
		
		//Creo gli allarmi
		//Variabile contentenente il tempo di attiavzione che mi ricavo da DB
		int Tempo_Attivazione = 0;
		
		//Variabile che contiene il nome da confrontare che mi ricavo da DB
		String nomeConfronto = null;
		
		//Variabile che contiene il nome del sensore di monitoraggio che mi ricavo da DB
		String nome = null; 
		
		//Variabile che contiene il nome del sensore da attivare
		String sensore_da_attivare = null;
		
		//Array list per gestirmi le variabili dal DB	
		ArrayList<Sensori_Monitoraggio> a = null;
		try {
			a = Gestione_Database.elenco_SM();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Array list per gestirmi le variabili dal DB	
		ArrayList<Sensori_Attivabili> sa= null;
		try {
			sa = Gestione_Database.elenco_SA();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//While per l'attivazione continua di allarmi
		while (attiva == 1) {
			Singleton s2 = Singleton.factory();
			attiva = s2.getMyInt2();
		System.out.println("Sto nel primo While\n-----------------------------");
		
		//Tempo di attesa tra un errore e l'altro (Un minuto)
		try {
			Thread.sleep(60000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		System.out.println("Mi stavo riposonado\n-----------------------------");
		
		//Random per creare errori su Sensori differenti
		int i = (int) (Math.random()*2);
		System.out.println("i=" +i+ "\n-----------------------------");
		
		//if per verificare che la mia random non sia piu grande del numero delle mie tuple
		if (i<a.size()) {
			System.out.println("Sto nel if\n-----------------------------");
			nome = (a.get(i).getNome_SM());
			sensore_da_attivare = (a.get(i).getSensore_Attivato());
			
			//For per scorrere nel DB tutti i sensori attivabili
				for (int j=0; j<sa.size();j++) {
					nomeConfronto = (sa.get(j).getNome_SA());
					
					//If per confrontare il nome confronto (Sensore Attivabile) con il nome sensore da attivare (Sensore monitoraggio).
						if (nomeConfronto.equals(sensore_da_attivare)) {
							System.out.println("nome confronto: " + nomeConfronto + "\n-----------------------------");
							Tempo_Attivazione = (sa.get(j).getTempo_Attivazione());
							System.out.println("tempo attivazione: " + Tempo_Attivazione + "\n-----------------------------");
							
							//Aggiungo il tempo attivazione alla coda.
							coda.add(Tempo_Attivazione);
							System.out.println(coda + "\n-----------------------------");
							
							//Implemento lo State Pattern
							Stato statoAllarme = allarme.getStatoAllarme();
							statoAllarme.gestioneStatoAllarme ( allarme, "in_pausa");
							statoAllarme = allarme.getStatoAllarme();
							System.out.println ("Stato Attuale Allarme: "+ statoAllarme);
							
							
							System.out.println("Sensore:" + nome + "\n-----------------------------");
							System.out.println("Sensore da Attivare:" + sensore_da_attivare + "\n-----------------------------");
							System.out.println("Tempo Attivazione:" + Tempo_Attivazione + "\n-----------------------------");
						}
						else if (!nomeConfronto.equals (sensore_da_attivare)) {
							System.out.println("Errore" + "\n-----------------------------");
							
							
							//Implemento lo State Pattern
							Stato statoAllarme = allarme.getStatoAllarme();
							statoAllarme.gestioneStatoAllarme ( allarme, "errore");
							statoAllarme = allarme.getStatoAllarme();
							System.out.println ("Stato Attuale Allarme: "+ statoAllarme);
						}
				}
		}
	}
}
}