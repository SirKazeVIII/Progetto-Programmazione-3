
package main;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

/**
 * Questa classe � il main del mio Programma. una semplice interffaccia grafica
 * che con i vari Panel mi permette di utilizzare tutto il progetto.
 */

public class InterfaccciaGrafica extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel panelMain;
	
	private PannelloAttivaSensori pannelloAttivaSensori;
	private PannelloSensoriMonitoraggio pannelloSensoriMonitoraggio;
	private PannelloSensoriAttivabili pannelloSensoriAttivabili;
	private PannelloAddOn pannelloAddOn;
	private PannelloVisualizzaDati pannelloVisualizzaDati;
	private PannelloInfo pannelloInfo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InterfaccciaGrafica frame = new InterfaccciaGrafica();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InterfaccciaGrafica() {
		setLocationRelativeTo(null);
		setAutoRequestFocus(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 576);
		setUndecorated(true);
		panelMain = new JPanel();
		panelMain.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		panelMain.setForeground(Color.BLACK);
		panelMain.setBackground(new Color(102, 153, 204));
		setContentPane(panelMain);
		panelMain.setLayout(null);
		
		pannelloAttivaSensori = new PannelloAttivaSensori();
		pannelloSensoriMonitoraggio = new PannelloSensoriMonitoraggio();
		pannelloSensoriAttivabili = new PannelloSensoriAttivabili();
		pannelloAddOn = new PannelloAddOn();
		pannelloVisualizzaDati = new PannelloVisualizzaDati();
		pannelloInfo = new PannelloInfo();

		
		final JPanel panelTendina = new JPanel();
		panelTendina.setBackground(new Color(0, 153, 204));
		panelTendina.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelTendina.setBounds(0, 0, 253, 576);
		panelMain.add(panelTendina);
		panelTendina.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Benvenuto");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(31, 11, 189, 43);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 35));
		panelTendina.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nella Tua");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(68, 49, 99, 25);
		panelTendina.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Casa Domotica");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_2.setBounds(10, 65, 233, 43);
		panelTendina.add(lblNewLabel_2);
		
		final JPanel panelAttivaSensori = new JPanel();
		panelAttivaSensori.addMouseListener(new PanelButtonMouseAdapter (panelAttivaSensori){
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(pannelloAttivaSensori);
			}
		});
		panelAttivaSensori.setForeground(Color.WHITE);
		panelAttivaSensori.setBackground(new Color(0, 153, 204));
		panelAttivaSensori.setBorder(new LineBorder(Color.BLACK, 2, true));
		panelAttivaSensori.setBounds(0, 160, 253, 55);
		panelTendina.add(panelAttivaSensori);
		panelAttivaSensori.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("Attiva/Disattiva Sensori");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setBounds(5, 10, 253, 31);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		panelAttivaSensori.add(lblNewLabel_3);
		
		JPanel panelAggiungiSM = new JPanel();
		panelAggiungiSM.addMouseListener(new PanelButtonMouseAdapter (panelAggiungiSM){
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(pannelloSensoriMonitoraggio);
			}
		});
		panelAggiungiSM.setBackground(new Color(0, 153, 204));
		panelAggiungiSM.setBorder(new LineBorder(Color.BLACK, 2, true));
		panelAggiungiSM.setBounds(0, 215, 253, 55);
		panelTendina.add(panelAggiungiSM);
		panelAggiungiSM.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("Sensori Monitoraggio");
		lblNewLabel_4.setForeground(Color.WHITE);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_4.setBounds(5, 10, 233, 33);
		panelAggiungiSM.add(lblNewLabel_4);
		
		JPanel panelAggiungiSA = new JPanel();
		panelAggiungiSA.addMouseListener(new PanelButtonMouseAdapter (panelAggiungiSA){
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(pannelloSensoriAttivabili);
			}
		});
		panelAggiungiSA.setBackground(new Color(0, 153, 204));
		panelAggiungiSA.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelAggiungiSA.setBounds(0, 270, 253, 55);
		panelTendina.add(panelAggiungiSA);
		panelAggiungiSA.setLayout(null);
		
		JLabel lblNewLabel_5 = new JLabel("Sensori Attivabili\r\n");
		lblNewLabel_5.setForeground(Color.WHITE);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_5.setBounds(5, 10, 219, 33);
		panelAggiungiSA.add(lblNewLabel_5);
		
		JPanel panelAggiungiAdd_On = new JPanel();
		panelAggiungiAdd_On.addMouseListener(new PanelButtonMouseAdapter (panelAggiungiAdd_On){
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(pannelloAddOn);
			}
		});
		panelAggiungiAdd_On.setBackground(new Color(0, 153, 204));
		panelAggiungiAdd_On.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelAggiungiAdd_On.setBounds(0, 325, 253, 55);
		panelTendina.add(panelAggiungiAdd_On);
		panelAggiungiAdd_On.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("Add-On");
		lblNewLabel_6.setForeground(Color.WHITE);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_6.setBounds(5, 11, 186, 33);
		panelAggiungiAdd_On.add(lblNewLabel_6);
		
		JPanel panelVisualizzaDati = new JPanel();
		panelVisualizzaDati.addMouseListener(new PanelButtonMouseAdapter (panelVisualizzaDati){
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(pannelloVisualizzaDati);
			}
		});
		panelVisualizzaDati.setBackground(new Color(0, 153, 204));
		panelVisualizzaDati.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelVisualizzaDati.setBounds(0, 380, 253, 55);
		panelTendina.add(panelVisualizzaDati);
		panelVisualizzaDati.setLayout(null);
		
		JLabel lblNewLabel_7 = new JLabel("Visualizza Dati");
		lblNewLabel_7.setForeground(Color.WHITE);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_7.setBounds(5, 10, 220, 33);
		panelVisualizzaDati.add(lblNewLabel_7);
		
		JPanel panelInfo = new JPanel();
		panelInfo.addMouseListener(new PanelButtonMouseAdapter (panelInfo){
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(pannelloInfo);
			}
		});
		panelInfo.setBackground(new Color(0, 153, 204));
		panelInfo.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		panelInfo.setBounds(0, 435, 253, 55);
		panelTendina.add(panelInfo);
		panelInfo.setLayout(null);
		
		JLabel lblNewLabel_8 = new JLabel("Info");
		lblNewLabel_8.setBounds(5, 11, 53, 31);
		lblNewLabel_8.setForeground(Color.WHITE);
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 25));
		panelInfo.add(lblNewLabel_8);
		
		JLabel lblExit = new JLabel("X");
		lblExit.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if (JOptionPane.showConfirmDialog(null, "Vuoi uscire dall'applicazione?", "Exit", JOptionPane.YES_NO_OPTION) == 0) {
					InterfaccciaGrafica.this.dispose();
				}
			}
		});
		
		lblExit.setForeground(Color.RED);
		lblExit.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblExit.setBounds(1005, 0, 15, 25);
		panelMain.add(lblExit);
		
		JPanel panelCentrale = new JPanel();
		panelCentrale.setBounds(263, 31, 751, 535);
		panelMain.add(panelCentrale);
		panelCentrale.setLayout(null);
		
		
		panelCentrale.add(pannelloAttivaSensori);
		panelCentrale.add(pannelloSensoriMonitoraggio);
		panelCentrale.add(pannelloSensoriAttivabili);
		panelCentrale.add(pannelloAddOn);
		panelCentrale.add(pannelloVisualizzaDati);
		panelCentrale.add(pannelloInfo);
		
		menuClicked(pannelloInfo);
	}
	
	public void menuClicked(JPanel panel) {
		pannelloAttivaSensori.setVisible(false);
		pannelloSensoriMonitoraggio.setVisible(false);
		pannelloSensoriAttivabili.setVisible(false);
		pannelloAddOn.setVisible(false);
		pannelloVisualizzaDati.setVisible(false);
		pannelloInfo.setVisible(false);
		panel.setVisible(true);
	}
	
	private class PanelButtonMouseAdapter extends MouseAdapter{
		
		JPanel panel;
		public PanelButtonMouseAdapter (JPanel panel) {
			this.panel = panel;
		}
		
		@Override
		public void mouseEntered (MouseEvent e) {
			panel.setBackground(new Color(0, 255, 255));
			
		}
		
		@Override
		public void mouseExited (MouseEvent e) {
			panel.setBackground(new Color(0, 153, 204));
			
		}
		
		@Override
		public void mousePressed (MouseEvent e) {
			panel.setBackground(new Color(255, 255, 255));			
		}
		
		@Override
		public void mouseReleased (MouseEvent e) {
			panel.setBackground(new Color(0, 153, 204));
			
		}
	}
}
