package main;

import java.awt.Color;

import javax.swing.JPanel;
import java.awt.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import DataBase.Gestione_Database;
import DataBase.Sensori_Monitoraggio;
import DataBase.Sensori_Attivabili;
import decorator_Pattern.*;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

/**
 * Panel che mi permette di aggiungere AddOn ai miei sensori modificando le tuple nel DB.
 */

public class PannelloAddOn extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textAddOn;
	private List list;
	private ArrayList<Sensori_Monitoraggio> risultati = new ArrayList<Sensori_Monitoraggio>();
	private ArrayList<Sensori_Attivabili> risultati2 = new ArrayList <Sensori_Attivabili>();

	/**
	 * Create the panel.
	 */
	public PannelloAddOn() {
		setBackground(new Color(0, 153, 204));
		setBounds (0,0,751, 535);
		setLayout(null);
		
		list = new List();
		list.setBounds(10, 10, 350, 515);
		add(list);
		
		//Bottone per visualizzare i sensori di monitoraggio.
		JButton btnVisualizzaSM = new JButton("Visualizza Sensori M.");
		btnVisualizzaSM.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				caricaLista();
			}
		});
		btnVisualizzaSM.setBounds(367, 96, 155, 75);
		add(btnVisualizzaSM);
		
		JLabel lblNewLabel = new JLabel("AddOn");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setBounds(366, 210, 110, 14);
		add(lblNewLabel);
		
		textAddOn = new JTextField();
		textAddOn.setBounds(366, 229, 156, 20);
		add(textAddOn);
		textAddOn.setColumns(10);
		
		//Bottone per Aggiungere un AddOn al sensore monitoraggio scelto.
		JButton btnAggiungiAddOnSM = new JButton("Aggiungi AddOn S.M.");
		btnAggiungiAddOnSM.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int elementoSelezionato = list.getSelectedIndex();
				if (elementoSelezionato >= 0) {
					String addOn = textAddOn.getText();
					String nome_SM = risultati.get(elementoSelezionato).getNome_SM();
					int consumo_SM = risultati.get(elementoSelezionato).getConsumo_SM();
					
					//Avvio il Decorator Pattern.
					Client aggiungiConsumoSM = new Add_On (new SensoreMonitoraggio());
					
					Sensori_Monitoraggio sm = new Sensori_Monitoraggio (nome_SM, null, consumo_SM+aggiungiConsumoSM.getConsumo(), null, addOn);
					Gestione_Database.modificaSensoreMonitoraggio(sm);
					caricaLista();
				}
			}
		});
		btnAggiungiAddOnSM.setBounds(366, 278, 156, 75);
		add(btnAggiungiAddOnSM);
		
		//Bottone per visualizzare i sensori attivabili.
		JButton btnVisualizzaSA = new JButton("Visualizza Sensori A.");
		btnVisualizzaSA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				caricaLista2();
			}
		});
		btnVisualizzaSA.setBounds(584, 96, 156, 75);
		add(btnVisualizzaSA);
		
		//Bottone per Aggiungere un AddOn al sensore attivabile scelto.
		JButton btnAggiungiAddOnSA = new JButton("Aggiungi AddOn S.A.");
		btnAggiungiAddOnSA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int elementoSelezionato = list.getSelectedIndex();
				if (elementoSelezionato >= 0) {
					String addOn = textAddOn.getText();
					String nome_SA = risultati2.get(elementoSelezionato).getNome_SA();
					int consumo_SA = risultati2.get(elementoSelezionato).getConsumo_SA();
					
					//Avvio il Decorator Pattern.
					Client aggiungiConsumoSA = new Add_On (new SensoreAttivo());
						
					Sensori_Attivabili sa = new Sensori_Attivabili (nome_SA, null, consumo_SA+aggiungiConsumoSA.getConsumo(), 0, addOn);
					Gestione_Database.modificaSensoreAttivabile(sa);
					caricaLista2();
				}
			}
		});
		btnAggiungiAddOnSA.setBounds(584, 278, 156, 75);
		add(btnAggiungiAddOnSA);
		setVisible(true);

	}
	private void caricaLista() {
		try {
			risultati = Gestione_Database.elenco_SM();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.removeAll();
		for (int i = 0; i< risultati.size(); i++) {
			list.add (risultati.get(i).getNome_SM() + " " + risultati.get(i).getTipo_Consumo_SM() + " " + risultati.get(i).getConsumo_SM() + " " + risultati.get(i).getSensore_Attivato() + " " + risultati.get(i).getAddOn());
		}
	}
	
	private void caricaLista2() {
		try {
			risultati2 = Gestione_Database.elenco_SA();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.removeAll();
		for (int i = 0; i< risultati2.size(); i++) {
			list.add(risultati2.get(i).getNome_SA() + " " + risultati2.get(i).getTipo_Consumo_SA() + " " + risultati2.get(i).getConsumo_SA() + " " + risultati2.get(i).getTempo_Attivazione()+ " " + risultati2.get(i).getAddOn());
		}
	}
}

