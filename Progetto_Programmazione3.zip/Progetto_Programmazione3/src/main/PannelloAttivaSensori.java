package main;

import java.awt.Color;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import state_Pattern.*;
import singleton_Pattern.Singleton;

/**
 * Panel che mi permette di attivare e disattivare tutti i miei sensori in modo che possano
 * generare tutti i dati per poi salvarli nel DB.
 */

public class PannelloAttivaSensori extends JPanel {
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		int attiva = 0;
	/**
	 * Create the panel.
	 */
	public PannelloAttivaSensori() {
		setBackground(new Color(0, 153, 204));
		setBounds (0,0,751, 535);
		setLayout(null);
		setVisible(true);
		
		//Attivo i Sensori.
		JButton btnAttivaSensore = new JButton("Attiva Sensore");
		btnAttivaSensore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				attiva = 1;
				JOptionPane.showMessageDialog(null, "Sensori Attivati");
				System.out.println("Sensori Attivati:" + attiva);
				
				//Implemento lo State Pattern.
				Allarme allarme = new Allarme();
				Stato statoAllarme = allarme.getStatoAllarme();
				System.out.println("Stato Allarme: " +statoAllarme);
				statoAllarme.gestioneStatoAllarme ( allarme, "attivo");
				statoAllarme = allarme.getStatoAllarme();
				
				//Avvio CodaRun e CreaRun, passando tramite il Singleton attiva.
				Singleton s1 = Singleton.factory();
				s1.setMyInt2(attiva);
				CreaRun creaRun = new CreaRun();
				Thread t = new Thread (creaRun);
				t.start();
				System.out.println("CreaRun Attivata\n-----------------------------");
				
				CodaRun codaRun = new CodaRun (creaRun);
				Thread z = new Thread (codaRun);
				z.start();
				System.out.println("CodaRun Attivata\n-----------------------------");
			}
		});
		btnAttivaSensore.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnAttivaSensore.setBounds(56, 189, 250, 150);
		add(btnAttivaSensore);
		
		//Disattivo i sensori.
		JButton btnDisattivaSensore = new JButton("Disattiva Sensore");
		btnDisattivaSensore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				attiva = 0;
				JOptionPane.showMessageDialog(null, "Sensori Disattivati");
				System.out.println("Sensori Disattivati:" + attiva);
				
				//Implemento lo State Pattern.
				Allarme allarme = new Allarme();
				Stato statoAllarme = allarme.getStatoAllarme();
				statoAllarme.gestioneStatoAllarme ( allarme, "finito");
				statoAllarme = allarme.getStatoAllarme();
				System.out.println ("Stato Attuale Allarme: "+ statoAllarme);
				
				//Passo i valore 0 di attiva tramite il Singleton.
				Singleton s1 = Singleton.factory();
				s1.setMyInt2(attiva);
				}
		});
		btnDisattivaSensore.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnDisattivaSensore.setBounds(448, 189, 250, 150);
		add(btnDisattivaSensore);

	}
}