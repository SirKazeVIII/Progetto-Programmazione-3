package main;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;

/**
 * Semplice Panel che spiega il funzionamento del programma e che fa da Home.
 */

public class PannelloInfo extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public PannelloInfo() {
		setBackground(new Color(0, 153, 204));
		setBounds (0,0,751, 535);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Benvenuto All'interno della applicazione che ti permette di \r\n");
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setToolTipText("");
		lblNewLabel.setLabelFor(this);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setBounds(10, 11, 731, 25);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("controllare tutti i sensori della tua casa domotica.");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(10, 47, 731, 25);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Da qui potrai attivare tutti i sensori aggiungerne");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2.setBounds(10, 83, 731, 25);
		add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("di nuovi o eliminare i vecchi, ");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3.setBounds(10, 116, 731, 25);
		add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("in pi\u00F9 potrai anche monitorare costantemente");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_4.setBounds(10, 146, 731, 25);
		add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("i vari allarmi che verrano generati dai tuoi sensori.");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_5.setBounds(10, 182, 731, 25);
		add(lblNewLabel_5);
		setVisible(true);

	}
}
