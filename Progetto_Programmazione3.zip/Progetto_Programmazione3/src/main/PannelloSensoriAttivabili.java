package main;

import java.awt.Color;

import javax.swing.JPanel;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JTextField;

import DataBase.Gestione_Database;
import DataBase.Sensori_Attivabili;

import javax.swing.JLabel;
import java.awt.Font;

/**
 * Panel che mi permette di agiungere o eliminare i Sensori Attivabili dal mio DB.
 */

public class PannelloSensoriAttivabili extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textNome;
	private JTextField textTipoConsumo;
	private JTextField textConsumo;
	private JTextField textTempoAttivazione;
	private List list;
	private ArrayList<Sensori_Attivabili> risultati = new ArrayList<Sensori_Attivabili>();
	private JTextField textAddOn;
	
	/**
	 * Create the panel.
	 */
	public PannelloSensoriAttivabili() {
		setBackground(new Color(0, 153, 204));
		setBounds (0,0,751, 535);
		setLayout(null);
		
		list = new List();
		list.setBounds(10, 10, 350, 515);
		add(list);
		
		//Bottone per visualizzare i sensori attivabili.
		JButton btnVisualizza = new JButton("Visualizza");
		btnVisualizza.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					caricaLista();
				}
		});
		btnVisualizza.setBounds(376, 96, 155, 75);
		add(btnVisualizza);
		
		//Bottone per eliminare i sensori attivabili.
		JButton btnElimina = new JButton("Elimina");
		btnElimina.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int elementoSelezionato = list.getSelectedIndex();
				Gestione_Database.eliminaSensore_Attivabili(risultati.get(elementoSelezionato));
					caricaLista();
				}
		});
		btnElimina.setBounds(574, 96, 156, 75);
		add(btnElimina);
		
		textNome = new JTextField();
		textNome.setBounds(376, 238, 155, 20);
		add(textNome);
		textNome.setColumns(10);
		
		textTipoConsumo = new JTextField();
		textTipoConsumo.setBounds(574, 238, 156, 20);
		add(textTipoConsumo);
		textTipoConsumo.setColumns(10);
		
		textConsumo = new JTextField();
		textConsumo.setBounds(376, 299, 155, 20);
		add(textConsumo);
		textConsumo.setColumns(10);
		
		textTempoAttivazione = new JTextField();
		textTempoAttivazione.setBounds(574, 299, 156, 20);
		add(textTempoAttivazione);
		textTempoAttivazione.setColumns(10);
		
		//Bottone per aggiungere un sensore attivabile nel DB.
		JButton btnAggiungi = new JButton("Aggiungi");
		btnAggiungi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nome = textNome.getText();
				String tipo_consumo = textTipoConsumo.getText();
				String consumo = textConsumo.getText();
				int consumoint = Integer.parseInt(consumo);
				String tempoAttivazione = textTempoAttivazione.getText();
				int tempoAttivazioneint = Integer.parseInt(tempoAttivazione);
				String addOn = textAddOn.getText();
				if (nome == null) {
					caricaLista();
				}
				else {
				Sensori_Attivabili salvaSA = new Sensori_Attivabili (nome, tipo_consumo, consumoint, tempoAttivazioneint, addOn);
				Gestione_Database.NuovoSensore_Attivabili(salvaSA);
				//ricarico la lista
				caricaLista();
				}
			}
		});
		btnAggiungi.setBounds(574, 379, 155, 75);
		add(btnAggiungi);
		
		JLabel lblNewLabel = new JLabel("Nome Sensore");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(376, 224, 155, 14);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Tipo Consumo");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(574, 224, 156, 14);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Consumo");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_2.setBounds(376, 284, 155, 14);
		add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Tempo Attivazione");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setBounds(574, 286, 156, 14);
		add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("AddOn");
		lblNewLabel_4.setForeground(Color.WHITE);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_4.setBounds(376, 330, 103, 14);
		add(lblNewLabel_4);
		
		textAddOn = new JTextField();
		textAddOn.setBounds(376, 345, 155, 20);
		add(textAddOn);
		textAddOn.setColumns(10);
		setVisible(true);
	}
	
	private void caricaLista() {
		try {
			risultati = Gestione_Database.elenco_SA();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.removeAll();
		for (int i = 0; i< risultati.size(); i++) {
			list.add("Nome Sensore--T.Consumo--Consumo--T.Attivazione--AddOn");
			list.add(risultati.get(i).getNome_SA() + " " + risultati.get(i).getTipo_Consumo_SA() + " " + risultati.get(i).getConsumo_SA() + " " + risultati.get(i).getTempo_Attivazione()+ " " + risultati.get(i).getAddOn());
		}
	}
}
