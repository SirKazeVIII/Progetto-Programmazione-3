package main;

import java.awt.Color;

import javax.swing.JPanel;
import java.awt.List;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import DataBase.Gestione_Database;
import DataBase.Sensori_Monitoraggio;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Panel che mi permette di agiungere o eliminare i Sensori di Monitoraggio dal mio DB.
 */

public class PannelloSensoriMonitoraggio extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textNome;
	private JTextField textTipoConsumo;
	private JTextField textConsumo;
	private JTextField textSensoreAttivato;
	private List list;
	private ArrayList<Sensori_Monitoraggio> risultati = new ArrayList<Sensori_Monitoraggio>();

	/**
	 * Create the panel.
	 */
	public PannelloSensoriMonitoraggio() {
		setBackground(new Color(0, 153, 204));
		setBounds (0,0,751, 535);
		setLayout(null);
		
		list = new List();
		list.setBounds(10, 10, 350, 515);
		add(list);
		
		//Bottone Per visualizzare i sensori monitoraggio.
		JButton btnVisualizza = new JButton("Visualizza");
		btnVisualizza.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("ciao");
				caricaLista();
			}
		});
		btnVisualizza.setBounds(367, 96, 155, 75);
		add(btnVisualizza);
		
		//Bottone per eliminare un sensore monitoraggio.
		JButton btnElimina = new JButton("Elimina");
		btnElimina.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int elementoSelezionato = list.getSelectedIndex();
				Gestione_Database.eliminaSensore_Monitoraggio(risultati.get(elementoSelezionato));
				// Ricarico la lista per vedere l'effettiva eliminazione
				caricaLista();
			}
		});
		btnElimina.setBounds(574, 96, 155, 75);
		add(btnElimina);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(367, 224, 155, 14);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Tipo Consumo");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(574, 224, 156, 14);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Consumo");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_2.setBounds(367, 284, 155, 14);
		add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Sensore Attivato");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_3.setBounds(574, 286, 156, 14);
		add(lblNewLabel_3);
		
		textNome = new JTextField();
		textNome.setBounds(367, 238, 155, 20);
		add(textNome);
		textNome.setColumns(10);
		
		textTipoConsumo = new JTextField();
		textTipoConsumo.setBounds(574, 238, 156, 20);
		add(textTipoConsumo);
		textTipoConsumo.setColumns(10);
		
		textConsumo = new JTextField();
		textConsumo.setBounds(367, 298, 156, 20);
		add(textConsumo);
		textConsumo.setColumns(10);
		
		textSensoreAttivato = new JTextField();
		textSensoreAttivato.setBounds(574, 299, 156, 20);
		add(textSensoreAttivato);
		textSensoreAttivato.setColumns(10);
		
		//Bottone per aggiungere un sensore monitoraggio al DB.
		JButton btnAggiungi = new JButton("Aggiungi");
		btnAggiungi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nome = textNome.getText();
				String tipoconsumo = textTipoConsumo.getText();
				String consumo = textConsumo.getText();
				int consumo1 = Integer.parseInt(consumo);
				String sensoreattivato = textSensoreAttivato.getText();
				if (nome == null) {
					caricaLista();
				}
				else {
				Sensori_Monitoraggio salvaSM = new Sensori_Monitoraggio (nome, tipoconsumo, consumo1, sensoreattivato, null);
				Gestione_Database.NuovoSensore_Monitoraggio(salvaSM);
				
				//ricarico la lista
				caricaLista();
				}
			}
		});

		btnAggiungi.setBounds(576, 348, 155, 75);
		add(btnAggiungi);
		setVisible(true);

	}
	private void caricaLista() {
		try {
			risultati = Gestione_Database.elenco_SM();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.removeAll();
		for (int i = 0; i< risultati.size(); i++) {
			list.add("Nome Sensore--T.Consumo--Consumo--Sensore Attivato--AddOn");
			list.add (risultati.get(i).getNome_SM() + " " + risultati.get(i).getTipo_Consumo_SM() + " " + risultati.get(i).getConsumo_SM() + " " + risultati.get(i).getSensore_Attivato() + " " + risultati.get(i).getAddOn());
		}
	}
}
