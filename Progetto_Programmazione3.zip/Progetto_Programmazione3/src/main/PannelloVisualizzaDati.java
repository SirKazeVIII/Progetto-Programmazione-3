package main;

import java.awt.Color;

import javax.swing.JPanel;

import DataBase.Allarme;
import DataBase.Gestione_Database;

import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;

/**
 * Panel che mi permette di visualizzare, eliminare o resettare gli allarmi dal mio DB.
 */

public class PannelloVisualizzaDati extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List list;
	private ArrayList<Allarme> risultati = new ArrayList<Allarme>();

	/**
	 * Create the panel.
	 */
	public PannelloVisualizzaDati() {
		setBackground(new Color(0, 153, 204));
		setBounds (0,0,751, 535);
		setLayout(null);
		
		list = new List();
		list.setBounds(10, 10, 350, 515);
		add(list);
		
		//Bottone per visualizzare i dati dell'allarme dal DB. 
		JButton btnVisualizza = new JButton("Visualizza");
		btnVisualizza.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					caricaLista();
				}
		});
		btnVisualizza.setBounds(484, 66, 155, 75);
		add(btnVisualizza);
		
		//Bottone per eliminare i dati dal DB.
		JButton btnElimina = new JButton("Elimina");
		btnElimina.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int elementoSelezionato = list.getSelectedIndex();
				Gestione_Database.eliminaAllarme(risultati.get(elementoSelezionato));
					caricaLista();
				}
		});
		btnElimina.setBounds(484, 214, 155, 75);
		add(btnElimina);
		
		//Bottone per eliminare tutti i dati di allarme del DB.
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Gestione_Database.ResetAllarme(null);
				caricaLista();
				}
		});
		btnReset.setBounds(484, 366, 155, 75);
		add(btnReset);
		setVisible(true);

	}
	
	private void caricaLista() {
		try {
			risultati = Gestione_Database.elenco_A();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.removeAll();
		for (int i = 0; i< risultati.size(); i++) {
			list.add("ID Allarme-------------Inzio Allarme---------------Fine Allarme---------");
			list.add("----------" + risultati.get(i).getID_Allarme() + "--------" + risultati.get(i).getData_Inizio() + "----" + risultati.get(i).getData_Fine());
		}
	}
}
