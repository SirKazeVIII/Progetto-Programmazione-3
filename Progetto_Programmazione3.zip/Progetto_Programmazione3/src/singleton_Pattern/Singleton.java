package singleton_Pattern;

public class Singleton {

	private int myint;
	private int myint2;
	
	/*
	Questa sara' l'unica istanza di questa classe.
	Ogni accesso avverr� tramite quest oggetto
	e non ne verranno creati altri.
	*/
	private static Singleton instance = null; 
	/*
	Costruttore privato per evitare la creazione di altre
	istanze dell'oggetto
	*/
	private Singleton(){
	}
	/*
	Unico punto di accesso all'istanza
	*/
	public static Singleton factory(){
	//creo l'oggetto se non esiste
	if(instance==null)
	instance = new Singleton();
	return instance;
	}
	public void setMyInt(int myint) {
		this.myint = myint;
	}
	public int getMyInt() {
		return myint;
	}
	public void setMyInt2(int myint2) {
		this.myint2 = myint2;
	}
	public int getMyInt2() {
		return myint2;
	}
}
