package state_Pattern;

/**
 * 
 *
 */
public class Allarme {
	private Stato statoAllarme;
		public Allarme() {
			this.statoAllarme = new StatoAttivo();
		}
		public Stato getStatoAllarme () {
			return statoAllarme;
	}
		public void setStatoAllarme (Stato StatoAllarme) {
			this.statoAllarme = StatoAllarme;
		}
}
