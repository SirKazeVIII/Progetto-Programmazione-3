package state_Pattern;

/**
 * Classe per provare il funzionamento dello State Pattern.
 *
 */

public class State_Pattern {

	public static void main(String[] args) {
		new State_Pattern().esecuzioneAllarme();
	}
	
	public void esecuzioneAllarme() {
		Allarme allarme = new Allarme();
		
		Stato statoAllarme = allarme.getStatoAllarme();
		System.out.println("Stato Allarme: " +statoAllarme);
		
		statoAllarme.gestioneStatoAllarme ( allarme, "attivo");
		statoAllarme = allarme.getStatoAllarme();
		System.out.println ("Stato Attuale Allarme: "+ statoAllarme);
		
		statoAllarme.gestioneStatoAllarme ( allarme, "in_pausa");
		statoAllarme = allarme.getStatoAllarme();
		System.out.println ("Stato Attuale Allarme: "+ statoAllarme);
		
		statoAllarme.gestioneStatoAllarme ( allarme, "acceso");
		statoAllarme = allarme.getStatoAllarme();
		System.out.println ("Stato Attuale Allarme: "+ statoAllarme);
		
		statoAllarme.gestioneStatoAllarme ( allarme, "errore");
		statoAllarme = allarme.getStatoAllarme();
		System.out.println ("Stato Attuale Allarme: "+ statoAllarme);
		
		
		statoAllarme.gestioneStatoAllarme ( allarme, "finito");
		statoAllarme = allarme.getStatoAllarme();
		System.out.println ("Stato Attuale Allarme: "+ statoAllarme);
	}

}
