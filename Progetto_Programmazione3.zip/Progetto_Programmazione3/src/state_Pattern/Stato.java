package state_Pattern;

/**
 * Classe per creare lo stato che verra cambiato di volta in volta. 
 *
 */

public interface Stato {
	
	public void gestioneStatoAllarme (Allarme allarme, String stato);

}
