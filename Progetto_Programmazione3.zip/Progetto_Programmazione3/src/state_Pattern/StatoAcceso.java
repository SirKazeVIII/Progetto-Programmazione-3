package state_Pattern;

public class StatoAcceso implements Stato {
	
	@Override
	public void gestioneStatoAllarme (Allarme allarme, String stato) {
		if (stato.equals("finito")) {
			allarme.setStatoAllarme(new StatoFinito());
		}
		else if (stato.equals("errore")) {
			allarme.setStatoAllarme(new StatoErrore());
		}
	}

}
