package state_Pattern;

public class StatoErrore implements Stato {
	
	@Override
	public void gestioneStatoAllarme (Allarme allarme, String stato) {
		if (stato.equals("finito"))
			allarme.setStatoAllarme(new StatoFinito());
	}
}