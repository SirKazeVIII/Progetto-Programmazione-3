package state_Pattern;

public class StatoFinito implements Stato {
	
	@Override
	public void gestioneStatoAllarme (Allarme allarme, String stato) {
	}
}