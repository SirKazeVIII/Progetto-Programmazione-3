package state_Pattern;

public class StatoInPausa implements Stato {
	
	@Override
	public void gestioneStatoAllarme (Allarme allarme, String stato) {
		if (stato.equals("acceso"))
			allarme.setStatoAllarme(new StatoAcceso());
	}

}
